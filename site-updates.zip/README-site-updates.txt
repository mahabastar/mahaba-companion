Site updates - copy these files into your repo, keeping the same paths.
This zip INCLUDES all earlier fixes (images, SEO titles, Privacy/Terms, packages, sitemap, gorilla pillar page), so use this one only.

LATEST:  Chimp posts (tracking guide, permit cost, Kibale vs Budongo); plus all earlier work

DELETE from the repo:  src/assets/founders/xavier-asaaba.png
Still broken:          src/assets/founders/herbert-muzoora.png (48-byte corrupt file) - re-upload the photo.

Earlier in this zip: permit guide rewrite, budget-gorilla-safari-uganda-cost post, journal post upgrades (headings, FAQs, schema), gorilla pillar page, sitemap additions, Privacy/Terms, packages, SEO titles, image fixes.
