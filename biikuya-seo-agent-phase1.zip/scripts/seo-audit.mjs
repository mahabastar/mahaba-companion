import fs from "node:fs/promises";

const SITE_URL = (process.env.SITE_URL || "https://www.biikuyatrailsuganda.com").replace(/\/+$/, "");
const reportFile = "seo-report.md";
const timeoutMs = 15000;
const maxPages = 150;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchText(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      redirect: "follow",
      signal: controller.signal,
      headers: { "User-Agent": "Biikuya-SEO-Agent/1.0 (+https://www.biikuyatrailsuganda.com)" },
      ...options,
    });
    const text = await res.text();
    return { res, text };
  } finally {
    clearTimeout(timer);
  }
}

function absoluteUrl(value) {
  try {
    return new URL(value, SITE_URL).href.split("#")[0].replace(/\/+$/, "") || SITE_URL;
  } catch {
    return null;
  }
}

function unique(arr) {
  return [...new Set(arr.filter(Boolean))];
}

function getTag(html, tag, attrName = "content") {
  const re = new RegExp(`<${tag}\\b[^>]*${attrName}=["']([^"']*)["'][^>]*>`, "i");
  const m = html.match(re);
  return m?.[1]?.trim() || "";
}

function getTitle(html) {
  return (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "")
    .replace(/\s+/g, " ").trim();
}

function getH1Count(html) {
  return (html.match(/<h1\b/gi) || []).length;
}

function hasCanonical(html) {
  return /<link\b[^>]*rel=["'][^"']*\bcanonical\b[^"']*["'][^>]*>/i.test(html);
}

function hasNoindex(html) {
  return /<meta\b[^>]*name=["']robots["'][^>]*content=["'][^"']*noindex/i.test(html);
}

function extractLinks(html) {
  const links = [];
  const re = /<a\b[^>]*href=["']([^"']+)["']/gi;
  let m;
  while ((m = re.exec(html))) {
    const href = m[1].trim();
    if (!href || href.startsWith("mailto:") || href.startsWith("tel:") ||
        href.startsWith("javascript:") || href.startsWith("#")) continue;
    try {
      const u = new URL(href, SITE_URL);
      if (u.origin === new URL(SITE_URL).origin) {
        links.push(u.href.split("#")[0].replace(/\/+$/, "") || SITE_URL);
      }
    } catch {}
  }
  return unique(links);
}

function extractImages(html) {
  const images = [];
  const re = /<img\b[^>]*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const tag = m[0];
    const src = tag.match(/\bsrc=["']([^"']+)["']/i)?.[1] || "";
    const alt = tag.match(/\balt=["']([^"']*)["']/i)?.[1];
    const width = tag.match(/\bwidth=["']([^"']+)["']/i)?.[1];
    const height = tag.match(/\bheight=["']([^"']+)["']/i)?.[1];
    images.push({ src, alt, width, height });
  }
  return images;
}

function esc(s) {
  return String(s ?? "").replace(/\|/g, "\\|");
}

const started = new Date();
const checks = [];
const pages = [];
const brokenLinks = [];
const warnings = [];
const errors = [];

async function checkEndpoint(label, url) {
  try {
    const { res } = await fetchText(url, { method: "GET" });
    const ok = res.status >= 200 && res.status < 400;
    checks.push({ label, url, status: res.status, ok });
    if (!ok) errors.push(`${label} returned HTTP ${res.status}: ${url}`);
  } catch (e) {
    checks.push({ label, url, status: "ERR", ok: false });
    errors.push(`${label} could not be reached: ${url} (${e.message})`);
  }
}

await checkEndpoint("Homepage", SITE_URL);
await checkEndpoint("robots.txt", `${SITE_URL}/robots.txt`);
await checkEndpoint("sitemap.xml", `${SITE_URL}/sitemap.xml`);

let sitemapUrls = [];
try {
  const { res, text } = await fetchText(`${SITE_URL}/sitemap.xml`);
  if (res.ok) {
    sitemapUrls = unique([...text.matchAll(/<loc>\s*([^<]+?)\s*<\/loc>/gi)].map(m => absoluteUrl(m[1])));
  }
} catch {}

let crawlQueue = unique([SITE_URL, ...sitemapUrls]).slice(0, maxPages);
const seen = new Set();

while (crawlQueue.length && seen.size < maxPages) {
  const url = crawlQueue.shift();
  if (!url || seen.has(url)) continue;
  seen.add(url);

  try {
    const { res, text: html } = await fetchText(url);
    const contentType = res.headers.get("content-type") || "";
    const isHtml = contentType.includes("text/html");

    const record = {
      url,
      status: res.status,
      title: "",
      description: "",
      h1: 0,
      canonical: false,
      noindex: false,
      images: 0,
      imagesMissingAlt: 0,
      imagesMissingDimensions: 0,
    };

    if (res.status < 200 || res.status >= 400) {
      errors.push(`Page returned HTTP ${res.status}: ${url}`);
    }

    if (isHtml) {
      record.title = getTitle(html);
      record.description = getTag(html, "meta", "content"); // corrected below when name=description
      const descMatch = html.match(/<meta\b[^>]*name=["']description["'][^>]*content=["']([^"']*)["'][^>]*>/i)
        || html.match(/<meta\b[^>]*content=["']([^"']*)["'][^>]*name=["']description["'][^>]*>/i);
      record.description = descMatch?.[1]?.trim() || "";
      record.h1 = getH1Count(html);
      record.canonical = hasCanonical(html);
      record.noindex = hasNoindex(html);

      const images = extractImages(html);
      record.images = images.length;
      record.imagesMissingAlt = images.filter(i => i.alt === undefined || i.alt.trim() === "").length;
      record.imagesMissingDimensions = images.filter(i => !i.width || !i.height).length;

      if (!record.title) warnings.push(`Missing title: ${url}`);
      if (!record.description) warnings.push(`Missing meta description: ${url}`);
      if (record.h1 === 0) warnings.push(`Missing H1: ${url}`);
      if (record.h1 > 1) warnings.push(`Multiple H1s (${record.h1}): ${url}`);
      if (!record.canonical) warnings.push(`Missing canonical: ${url}`);
      if (record.noindex) warnings.push(`NOINDEX detected: ${url}`);
      if (record.imagesMissingAlt) warnings.push(`${record.imagesMissingAlt} image(s) missing alt text: ${url}`);
      if (record.imagesMissingDimensions) warnings.push(`${record.imagesMissingDimensions} image(s) missing width/height: ${url}`);

      const discovered = extractLinks(html);
      for (const link of discovered) {
        if (!seen.has(link) && !crawlQueue.includes(link) && crawlQueue.length < maxPages * 2) {
          crawlQueue.push(link);
        }
      }
    }

    pages.push(record);
  } catch (e) {
    errors.push(`Could not crawl ${url}: ${e.message}`);
  }

  await sleep(100);
}

const totalPages = pages.length;
const pagesWithTitles = pages.filter(p => p.title).length;
const pagesWithDescriptions = pages.filter(p => p.description).length;
const pagesWithCanonical = pages.filter(p => p.canonical).length;
const pagesWithNoindex = pages.filter(p => p.noindex).length;
const totalMissingAlt = pages.reduce((n, p) => n + p.imagesMissingAlt, 0);
const totalMissingDimensions = pages.reduce((n, p) => n + p.imagesMissingDimensions, 0);

const statusEmoji = errors.length ? "🔴" : warnings.length ? "🟠" : "🟢";

const lines = [];
lines.push(`# Biikuya Trails Uganda — SEO Health Report`);
lines.push(``);
lines.push(`**Run:** ${started.toISOString()}`);
lines.push(`**Site:** ${SITE_URL}`);
lines.push(`**Overall:** ${statusEmoji} ${errors.length ? "Errors found" : warnings.length ? "Warnings found" : "No issues detected by this audit"}`);
lines.push(``);
lines.push(`## Summary`);
lines.push(``);
lines.push(`| Check | Result |`);
lines.push(`|---|---:|`);
lines.push(`| Pages crawled | ${totalPages} |`);
lines.push(`| Pages with title | ${pagesWithTitles}/${totalPages} |`);
lines.push(`| Pages with meta description | ${pagesWithDescriptions}/${totalPages} |`);
lines.push(`| Pages with canonical | ${pagesWithCanonical}/${totalPages} |`);
lines.push(`| Pages with NOINDEX | ${pagesWithNoindex} |`);
lines.push(`| Images missing alt | ${totalMissingAlt} |`);
lines.push(`| Images missing width/height | ${totalMissingDimensions} |`);
lines.push(`| Errors | ${errors.length} |`);
lines.push(`| Warnings | ${warnings.length} |`);
lines.push(``);

lines.push(`## Endpoint checks`);
lines.push(``);
lines.push(`| Endpoint | HTTP | Status |`);
lines.push(`|---|---:|---|`);
for (const c of checks) lines.push(`| ${esc(c.label)} | ${c.status} | ${c.ok ? "PASS" : "FAIL"} |`);
lines.push(``);

if (errors.length) {
  lines.push(`## 🔴 Errors`);
  lines.push(``);
  for (const x of errors) lines.push(`- ${x}`);
  lines.push(``);
}

if (warnings.length) {
  lines.push(`## 🟠 Warnings`);
  lines.push(``);
  for (const x of warnings.slice(0, 200)) lines.push(`- ${x}`);
  if (warnings.length > 200) lines.push(`- …and ${warnings.length - 200} more.`);
  lines.push(``);
}

lines.push(`## Page details`);
lines.push(``);
lines.push(`| URL | HTTP | Title | Description | H1 | Canonical | Noindex | Images | Alt missing | Dimensions missing |`);
lines.push(`|---|---:|---|---|---:|---|---|---:|---:|---:|`);
for (const p of pages) {
  lines.push(`| ${esc(p.url)} | ${p.status} | ${p.title ? "Yes" : "NO"} | ${p.description ? "Yes" : "NO"} | ${p.h1} | ${p.canonical ? "Yes" : "NO"} | ${p.noindex ? "YES" : "No"} | ${p.images} | ${p.imagesMissingAlt} | ${p.imagesMissingDimensions} |`);
}
lines.push(``);
lines.push(`---`);
lines.push(`Generated automatically by the Biikuya Trails Uganda SEO Agent. This first version is **audit-only** and does not modify the website.`);

await fs.writeFile(reportFile, lines.join("\n"), "utf8");

console.log(`SEO audit complete: ${reportFile}`);
console.log(`Pages: ${totalPages}; errors: ${errors.length}; warnings: ${warnings.length}`);

if (errors.length) process.exitCode = 1;
