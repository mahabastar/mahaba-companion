# Biikuya Trails Uganda SEO Agent — Phase 1

This first version is intentionally **audit-only**.

It:
- checks the live website, robots.txt and sitemap.xml
- crawls up to 150 internal pages
- checks HTTP status
- checks page titles
- checks meta descriptions
- checks H1 count
- checks canonical tags
- flags noindex
- checks image alt text
- checks image width/height
- uploads a Markdown report as a GitHub Actions artifact

It does NOT change website code or deploy anything.

## Install

Copy these two items into the root of your GitHub repository:

- `.github/workflows/seo-audit.yml`
- `scripts/seo-audit.mjs`

The workflow runs:
- whenever code is pushed to `main`
- manually from GitHub Actions
- every day at 06:00 Uganda time (03:00 UTC)

## Run manually

GitHub → your repository → Actions → "Biikuya SEO Health Check" → Run workflow.

After it finishes, open the run and download the `biikuya-seo-report` artifact.

## Next phases

Phase 2: Search Console data + weekly SEO report.
Phase 3: AI recommendations.
Phase 4: controlled, approval-based fixes.
